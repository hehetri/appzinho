Deliveroo Ireland Limited
15 Flemmings Place
Dublin 4
Company Number: 556923
Name: Lucas Moreira
Address: D01KF30, dublin, Ireland
Self-Billing Invoice
Services Rendered: Food and Beverage Delivery
Invoice serial number: ri_ie_c10f1af0-57ae-4d88-8424-9b364b3c7768_69
Invoice period: 10 April 2025 - 10 April 2025
Invoice Date: 10 April 2025
Deliveries
Day
Date
Orders Delivered
Total
Thursday
10 April 2025
6
Û45.82
Total
6
Û45.82
Invoice Total
Item totals
Total
Gross
Deliveries
Û45.82
Û45.82
Transaction fee
(Û0.50)
(Û0.50)
Adjustments
--
--
Tips
Û5.00
Û5.00
Total
Û50.32
Û50.32
Total fee payable: Û50.32
This self billing invoice is issued in the name, and on behalf of, the supplier Lucas Moreira in accordance with the
terms of the rider supplier agreement between the parties.
1
